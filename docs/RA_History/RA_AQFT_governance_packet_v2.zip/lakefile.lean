import Lake
open Lake DSL

package «RelationalActualism»

require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git"

-- AQFT governance note:
-- * The canonical AQFT root is RA_AQFT_Proofs_v10.lean.
-- * The Mathlib-only CFC support port lives in RA_CFC_Port.lean and is
--   imported by the canonical root in the proposed integration patch.
-- * RA_AQFT_Proofs.lean and RA_AQFT_CFC_Patch.lean are archival helper files,
--   not default roots, and should not be cited as the canonical AQFT closure.

@[default_target]
lean_lib «RelationalActualism» where
  roots := #[
    -- Core graph-theoretic foundations (L01, L02, L03)
    `RA_GraphCore,
    -- BDG particle classification (L08, L10, L11, L12, D1a–D1h)
    `RA_D1_Proofs,
    -- Koide lepton mass formula (L09)
    `RA_Koide,
    -- AQFT: frame independence, Rindler, CPTP (L04–L07)
    `RA_AQFT_Proofs_v10,
    -- Amplitude locality + causal invariance (O01, O02)
    `RA_AmpLocality,
    -- Spin-2 DOF count (O10s)
    `RA_Spin2_Macro,
    -- BDG uniqueness: Yeats → Möbius → coefficients (O14)
    `RA_O14_Uniqueness,
    -- Baryon conservation + chirality (D3a, D3b)
    `RA_BaryonChirality
  ]