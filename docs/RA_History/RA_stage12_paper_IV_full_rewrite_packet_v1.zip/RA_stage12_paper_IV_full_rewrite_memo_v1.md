# Paper IV full rewrite memo (v1)

This pass rewrites Paper IV front-to-back rather than patching isolated paragraphs.

## Governing doctrine implemented

The rewrite follows the suite doctrine now established across Papers I-III:

- RA's proof path remains native to DAG growth, the BDG acceptance kernel, the local ledger condition, kernel locality, and the compiled D1-native chain.
- Causal Set Theory is stated explicitly as the immediate mathematical lineage.
- Existing theories and programmes are used throughout as comparison classes, not as sources of RA's ontology or proof path.
- Open sectors are stated plainly, together with native routes forward.

## Main structural changes

1. The paper no longer reads as a history of how RA developed into a complexity programme.
   It now opens by stating the empirical domain directly: organized persistence, life, biosignatures, agency, and cognition.

2. CST is now explicit in the introduction and in the first substantive section.
   The paper says clearly what RA inherits from CST and what RA adds that matters for complexity: primitive actualization, the realized/potentia split, the LLC, kernel-local admissibility, and severance/boundary logic.

3. The section structure was rebuilt around a coherent native arc:
   - From CST to a complexity programme
   - Recursive closure and the causal firewall
   - Persistence windows and environmental overwrite
   - Finite assembly depth and reaction-network coarse-graining
   - Origin-of-life constraints and biosignature criteria
   - Perception, agency, and consciousness: structural constraints
   - What RA explains here, and what it does not yet explain

4. Compare-and-contrast is now woven through the paper wherever relevant:
   - CST and coarse-graining
   - systems biology / autopoiesis / Markov-blanket language
   - decoherence and quantum-Darwinist pictures
   - Assembly Theory
   - origin-of-life scenario work
   - panpsychism / IIT / artificial consciousness
   - standard quantum measurement language, including an explicit contrast with the need for a Born-rule layer

5. The strongest unsupported legacy claims remain removed from active support.
   Markov-blanket theorems, DFT support, KCB, Landauer, Maxwell, and related bridge clusters are not reinstated as active support.

## Strongest positive claims after rewrite

The paper now foregrounds the claims that are strongest in the current RA programme:

- recursive closure as a native organizational notion;
- the causal firewall as redundant boundary inscription plus bounded boundary turnover;
- persistence windows as the key viability question for living organization;
- finite assembly depth as the native complexity measure;
- substrate-independent biosignature criteria;
- structural constraints on perception, agency, panpsychism, and artificial consciousness.

## Explicit open targets now stated plainly

The rewrite names the main missing closures directly:

- theorem-level causal-shield law across coarse-graining levels;
- first-principles persistence-window formula;
- direct native computation for candidate prebiotic networks;
- mapping assembly depth to biological emergence probabilities;
- native derivation of perception-related frequency laws;
- any sufficient-condition theory of phenomenal consciousness.

## Build status

- TeX compiled successfully to PDF.
- The PDF was rendered and visually spot-checked after compilation.
