# RA Weak-Field Solar-System Recovery Note v1

## Purpose

This note is the first Solar-system benchmark packet following the Casimir note.

Its role is narrow and explicit:

1. state what the current RA suite already implies for Solar-system tests **if** the Paper III GR bridge is accepted in its stated domain,
2. compute two canonical observables from that bridge,
3. separate those **translation-level benchmark consequences** from the stronger but still-open target of a fully RA-native discrete weak-field derivation.

## Executive result

Under the Paper III bridge
\[
S_{\mathrm{BDG}} \to S_{\mathrm{EH}},\qquad
G_{\mu\nu} = 8\pi G\,P_{\mathrm{act}}[T_{\mu\nu}],\qquad \Lambda = 0,
\]
together with the dense-region statement that ordinary 4D GR is recovered when the actualization density is high, the following standard weak-field observables follow in the asymptotically flat vacuum exterior of the Sun:

- **Solar limb light deflection:** \(\alpha = 1.751243\) arcsec
- **Mercury anomalous perihelion advance:** \(\Delta\varpi = 42.982013\) arcsec/century

These are the standard Schwarzschild / PPN(\(\beta=\gamma=1\)) values.

## Status discipline

These numbers should **not** yet be presented as “direct discrete RA-native derivations.”  
The honest status is:

- **CV conditional on the Paper III GR bridge** and the standard spherically symmetric vacuum theorem of GR.
- **Not yet** a direct derivation from a canonical weak-field RA source law written purely in graph variables.
- **Not yet** a dedicated suite-primary Lean/Python benchmark module inside the current core bundle.

So they are strong **domain-recovery consequences**, but not yet the strongest possible RA-native benchmark closures.

## Common assumptions

### A1. Dense-region recovery
Paper III states that in dense regions of the causal graph the continuum limit is ordinary 4D general relativity.

### A2. Field-equation bridge
Paper III states that the BDG action converges to the Einstein–Hilbert action and that variation yields
\[
G_{\mu\nu} = 8\pi G\,P_{\mathrm{act}}[T_{\mu\nu}],\qquad \Lambda = 0.
\]

### A3. Solar-system regime
For the Sun and inner Solar system we assume the source sits in the dense 4D regime, with no sparse-halo correction term of the
\[
\nabla^2(\ln\lambda)
\]
type relevant to the observable at the required precision.

### A4. Vacuum exterior
Outside the source, the effective source term vanishes and the asymptotically flat, spherically symmetric exterior is the standard Schwarzschild vacuum solution.

### A5. PPN identification
At the benchmark level we identify the recovered vacuum solution with the standard PPN values
\[
\beta = 1,\qquad \gamma = 1.
\]

This is the translation step that converts the Paper III bridge into named Solar-system observables.

## Why this is already useful

These two benchmarks matter for your stated strategy because they do three things at once:

1. they show how the **GR bridge cashes out numerically** rather than rhetorically,
2. they give very recognizable observables for referees and skeptical readers,
3. they support the tractability claim: once the bridge is in place, the benchmark calculation is compact and fully explicit.

## What remains open

### O1. Direct RA-native weak-field source law
The suite still needs a canonical derivation of the effective weak-field metric or PPN parameters directly from graph variables and the actualization projector, not only through the Einstein–Hilbert translation.

### O2. Precision closure of dense-regime source tracking
Paper III currently states a WEP-style tracking estimate at the 1e-4 level for baryonic matter, while noting that the stronger equilibration closure needed for modern precision tests remains open.

### O3. Canonical benchmark integration into the papers
These Solar-system benchmarks are not yet woven into the current Paper III narrative as suite-primary benchmark notes.

### O4. Dedicated formal/computational support
The current core bundle includes Casimir, rotation-curve, Bullet Cluster, and DESI-oriented scripts, but no suite-primary Solar-system benchmark script was present in the uploaded core snapshot. This packet supplies one.

## Recommended paper-facing phrasing

A safe suite-primary sentence is:

> In the dense, asymptotically flat weak-field regime, the Paper III GR bridge implies the standard Schwarzschild / PPN(β=γ=1) Solar-system observables. As benchmark calculations, the Solar limb deflection and Mercury perihelion shift take their standard values. These are translation-level consequences of the recovered Einstein–Hilbert sector, while a direct RA-native derivation of the weak-field source law remains an open closure target.

## Numerical results

| Observable | Formula | Value |
|---|---|---:|
| Solar limb light deflection | \(4GM_\odot/(R_\odot c^2)\) | **1.751243 arcsec** |
| Mercury perihelion advance | \(6\pi GM_\odot/[a(1-e^2)c^2]\) per orbit | **0.103521 arcsec/orbit** |
| Mercury perihelion advance | converted to century rate | **42.982013 arcsec/century** |

## Bottom line

The suite is now in a better position to say something precise:

- **Casimir** is the strongest present benchmark for practical calculational usefulness.
- **Solar deflection** and **Mercury** are now explicit translation-level consequences of the Paper III bridge.
- The next closure target is a direct RA-native weak-field derivation, not merely another phenomenological script.
