# RA Benchmark Support Matrix v2

## Current benchmark tiers after the weak-field packet

| Benchmark | Current support in core snapshot | Present audit reading | Next closure step |
|---|---|---|---|
| Casimir effect | dedicated runnable script + benchmark note | **Strongest current calculational witness** | integrate into Paper I/III bridge language |
| Solar light deflection | **new** explicit benchmark note + script | **CV conditional on GR bridge** | direct RA-native weak-field optical metric |
| Mercury perihelion | **new** explicit benchmark note + script | **CV conditional on GR bridge** | direct RA-native post-Newtonian derivation |
| Rotation curves | Paper III proposition + script | useful but currently **calibrated / not first-principles closed** | replace fitted parameter by sourced RA quantity |
| Bullet Cluster | Paper III proposition + script | **open computational target** with honest caveats | derive covariant lensing source from canonical field equations |
| DESI / dark-energy reinterpretation | Paper III + scripts + MD notes | **phenomenological interpolation**, not theorem closure | full light-cone / inhomogeneous-distance treatment |
| KCB / spin-bath | Paper I + Paper IV + extra Lean/Python | strategically important but still blocked by provenance/formula issues | repair cross-paper coherence first |

## Interpretation

The benchmark ladder is now better ordered:

1. Casimir
2. Solar light deflection
3. Mercury perihelion
4. Rotation curves
5. Cluster lensing
6. Bullet Cluster / larger-scale covariant lensing
7. quantum-complexity / spin-bath observables once Paper IV coherence issues are repaired

## Practical message

The new weak-field packet improves the suite in an important way:
it gives two classical Solar-system numbers that can be stated cleanly without pretending that the direct discrete weak-field derivation is already finished.
