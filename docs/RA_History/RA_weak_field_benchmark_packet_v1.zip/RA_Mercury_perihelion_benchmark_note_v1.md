# RA Mercury Perihelion Benchmark Note v1

## Observable

Anomalous perihelion advance of Mercury beyond the Newtonian two-body prediction.

## Strategic role

Mercury is the classical high-prestige benchmark for any theory claiming to recover GR in its Solar-system domain.  
It is therefore the right partner to Solar light deflection in the first weak-field benchmark packet.

## Derivation chain used here

### RA-side assumptions
1. Dense-region actualization implies ordinary 4D GR in the relevant continuum limit.
2. The Paper III bridge yields
   \[
   G_{\mu\nu} = 8\pi G\,P_{\mathrm{act}}[T_{\mu\nu}],\qquad \Lambda = 0.
   \]
3. The Solar exterior is treated as the standard asymptotically flat spherical vacuum solution in the recovered Einstein sector.

### Translation step
At PPN level the weak-field metric takes the standard values
\[
\beta = 1,\qquad \gamma = 1.
\]

### Benchmark formula
The PPN perihelion advance per orbit is
\[
\Delta\varpi
= \frac{2 + 2\gamma - \beta}{3}
\cdot
\frac{6\pi GM}{a(1-e^2)c^2}.
\]
For \(\beta=\gamma=1\), this reduces to
\[
\Delta\varpi
=
\frac{6\pi GM}{a(1-e^2)c^2}.
\]

## Mercury evaluation

Using

- \(M = M_\odot = 1.98847\times 10^{30}\,\mathrm{kg}\)
- semimajor axis \(a = 5.7909\times 10^{10}\,\mathrm{m}\)
- eccentricity \(e = 0.205630\)
- orbital period \(P = 87.9691\) days

gives

\[
\Delta\varpi = 5.018819055e-07\,\mathrm{rad/orbit}
= 0.103521\,\mathrm{arcsec/orbit}.
\]

Converting using Mercury’s orbital rate gives

\[
\Delta\varpi_{\mathrm{century}}
= 42.982013\,\mathrm{arcsec/century}.
\]

## Comparison target

Canonical benchmark value: about \(43\) arcsec/century.

So the recovered value matches the standard Solar-system benchmark.

## Status

**CV conditional on the Paper III GR bridge.**

So again:
- the benchmark is explicit and script-reproduced,
- but it is not yet a direct discrete RA-native post-Newtonian derivation.

## Important caveat

Paper III’s current WEP/equilibration discussion is not yet a full precision-closure argument for all Solar-system tests.  
So the right public claim is not “RA has already independently rederived the full post-Newtonian Solar system from graph variables.”  
The right claim is that the recovered Einstein sector already yields the canonical Mercury benchmark in-domain, while the direct RA-native weak-field closure remains an active target.

## Bottom line

Within the recovered Einstein / PPN(β=γ=1) sector,
\[
\boxed{\Delta\varpi_{\mathrm{Mercury}} = 42.982013\ \text{arcsec/century}}.
\]
That is the correct next benchmark consequence to place beside Casimir and ahead of cluster-scale lensing claims.
