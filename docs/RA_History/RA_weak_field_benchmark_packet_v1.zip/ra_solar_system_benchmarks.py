"""
ra_solar_system_benchmarks.py

Relational Actualism — weak-field Solar-system benchmark packet

This script evaluates two canonical benchmark consequences of the Paper III
GR bridge, under the explicit assumption that in the dense, asymptotically
flat weak-field regime the recovered macroscopic metric is the standard
Schwarzschild / PPN(beta=gamma=1) exterior solution.

What this script DOES:
- Computes Solar-limb light deflection.
- Computes Mercury's anomalous perihelion advance.
- Makes the translation-level benchmark consequence fully explicit.

What this script DOES NOT claim:
- It does not provide a direct discrete RA-native derivation of the weak-field
  metric from graph variables.
- It does not by itself close the dense-regime equilibration / WEP precision
  gap discussed in Paper III.
"""

import math

# Fundamental constants (SI)
G = 6.67430e-11
c = 299792458.0
ARCSEC_PER_RAD = 206264.80624709636

# Solar constants
M_sun = 1.98847e30      # kg
R_sun = 6.957e8         # m

# Mercury orbital parameters
a_mercury = 57.909e9    # m
e_mercury = 0.205630
P_mercury_days = 87.9691
century_days = 36525.0

def light_deflection_ppn(M, b, gamma=1.0):
    """Leading weak-field deflection angle in radians."""
    return 2.0 * (1.0 + gamma) * G * M / (b * c**2)

def perihelion_advance_ppn(M, a, e, beta=1.0, gamma=1.0):
    """Anomalous perihelion advance per orbit in radians."""
    ppn_factor = (2.0 + 2.0 * gamma - beta) / 3.0
    return ppn_factor * 6.0 * math.pi * G * M / (a * (1.0 - e**2) * c**2)

def rad_to_arcsec(x):
    return x * ARCSEC_PER_RAD

def main():
    print("=" * 68)
    print("RELATIONAL ACTUALISM — WEAK-FIELD SOLAR-SYSTEM BENCHMARKS")
    print("=" * 68)
    print("Status: translation-level benchmark consequences of the Paper III")
    print("GR bridge, not yet direct discrete RA-native weak-field derivations.")
    print()

    # Solar limb light deflection
    alpha = light_deflection_ppn(M_sun, R_sun, gamma=1.0)
    alpha_arcsec = rad_to_arcsec(alpha)

    print("1) Solar limb light deflection")
    print("-" * 68)
    print("Formula: alpha = 2(1+gamma)GM/(bc^2), with gamma = 1 and b = R_sun")
    print(f"alpha = {alpha:.9e} rad")
    print(f"alpha = {alpha_arcsec:.6f} arcsec")
    print("Benchmark target: ~1.75 arcsec")
    print()

    # Mercury perihelion
    dphi = perihelion_advance_ppn(M_sun, a_mercury, e_mercury, beta=1.0, gamma=1.0)
    dphi_arcsec_orbit = rad_to_arcsec(dphi)
    orbits_per_century = century_days / P_mercury_days
    dphi_arcsec_century = dphi_arcsec_orbit * orbits_per_century

    print("2) Mercury anomalous perihelion advance")
    print("-" * 68)
    print("Formula: Δϖ = [(2+2γ-β)/3] * 6πGM/[a(1-e^2)c^2], with β=γ=1")
    print(f"Δϖ = {dphi:.9e} rad/orbit")
    print(f"Δϖ = {dphi_arcsec_orbit:.6f} arcsec/orbit")
    print(f"Δϖ = {dphi_arcsec_century:.6f} arcsec/century")
    print("Benchmark target: ~43 arcsec/century")
    print()

    print("Interpretation")
    print("-" * 68)
    print("If the Paper III GR bridge is accepted in the dense weak-field regime,")
    print("these observables follow immediately as in-domain consequences.")
    print("The next stronger closure target is a direct RA-native derivation of the")
    print("weak-field source law and post-Newtonian parameters from graph variables.")
    print("=" * 68)

if __name__ == "__main__":
    main()
