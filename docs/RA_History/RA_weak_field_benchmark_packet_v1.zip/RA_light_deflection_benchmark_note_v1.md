# RA Solar Light-Deflection Benchmark Note v1

## Observable

Total light-deflection angle for a null ray grazing the Solar limb.

## Strategic role

This is the cleanest first classical benchmark after Casimir.  
It is easier than cluster lensing, rhetorically stronger than another dark-sector plot, and directly tests whether the recovered macroscopic RA gravity sector reaches the canonical GR weak-field observable.

## Derivation chain used here

### RA-side assumptions
1. In dense regions, the continuum limit is ordinary 4D GR.
2. The Paper III bridge yields
   \[
   G_{\mu\nu} = 8\pi G\,P_{\mathrm{act}}[T_{\mu\nu}],\qquad \Lambda = 0.
   \]
3. Outside a static spherical source, the vacuum exterior is treated in the recovered Einstein sector.

### Translation step
For a static, spherically symmetric, asymptotically flat vacuum exterior, the recovered metric is the Schwarzschild metric.  
At PPN level this means \(\gamma=1\).

### Benchmark formula
The leading weak-field light-deflection angle for impact parameter \(b\) is
\[
\alpha = 2(1+\gamma)\frac{GM}{bc^2}.
\]
With \(\gamma=1\),
\[
\alpha = \frac{4GM}{bc^2}.
\]

For a grazing Solar ray, \(b = R_\odot\), so
\[
\alpha_\odot = \frac{4GM_\odot}{R_\odot c^2}.
\]

## Numerical evaluation

Using

- \(G = 6.67430\times 10^{-11}\,\mathrm{m^3\,kg^{-1}\,s^{-2}}\)
- \(M_\odot = 1.98847\times 10^{30}\,\mathrm{kg}\)
- \(R_\odot = 6.957\times 10^8\,\mathrm{m}\)
- \(c = 299792458\,\mathrm{m/s}\)

gives

\[
\alpha_\odot = 8.490267018e-06\,\mathrm{rad}
= 1.751243\,\mathrm{arcsec}.
\]

## Comparison target

Canonical benchmark value: about \(1.75\) arcsec at the Solar limb.

So the recovered value is fully consistent with the standard Solar-system benchmark.

## Status

**CV conditional on the Paper III GR bridge.**

That means:
- the numerical calculation is explicit and reproduced by script,
- but the benchmark still rests on the recovered Einstein / Schwarzschild sector,
- not yet on a fully discrete RA-native derivation of the weak-field optical metric.

## What would strengthen this benchmark further

1. derive the weak-field optical metric directly from a canonical RA source functional,
2. show explicitly that Solar-system \(\lambda\)-variation corrections are negligible at observational precision,
3. fold the benchmark into Paper III itself as a short benchmark subsection or note.

## Bottom line

If the Paper III GR bridge is accepted in its stated domain, Solar light deflection is no longer merely “expected”; it is an explicit benchmark consequence:
\[
\boxed{\alpha_\odot = 1.751243\ \text{arcsec}}.
\]
