# Pion and Kaon Instability: Extending the Five-Type σ-Filter Classification

**Status:** Research synthesis identifying the natural weak-decay extension of the established five-type strong-decay classification.

**Date:** April 16, 2026 (supersedes `RA_Pion_Kaon_Synthesis.md` v1)

**Precedent work (April 10–11, 2026, "Reconstructing RA 20260408" session):**
- `sigma_analysis.py`: five-type classification with empirical Σ_eff across 19 strongly-decaying particles
- `sigma_table.py`: complete σ-label table for 26 particles
- `bdg_multicoupling.py`: multi-coupling lifetime formula τ = (α_sustain/α_decay) · L · (ℏ/mc²)
- `pathwise_exit.py`: state-dependent Σ_k kernel for exit paths
- `branching_volume.py`: energy-budget daughter counting

All scripts reproduce cleanly (verified Apr 16 2026).

---

## 1. What is already established (strong decays)

The five-type σ-filter classification is a validated RA-native framework
for strong decays, covering 19 particles across 3 orders of magnitude in
lifetime:

| Type | Σ_eff | Mechanism | Examples |
|------|-------|-----------|----------|
| **I Direct** | ~1.0 (0.25–2.85) | Direct 2-body strong exit, no σ constraint | ρ, Δ, N(1440–1680), Δ(1600,1620) — 8 particles |
| **II Strangeness** | ~0.4 (0.08–1.15) | Flavor rearrangement required | K*, Σ*, Λ(1520), Σ(1670), Ξ*(1530) — 5 particles |
| **III G-parity** | ~0.09 (0.08–0.10) | 2-body blocked, forced multi-step | ω(782), a₀(980) — 2 particles |
| **IV Topology** | 0 exact | Profile (2,2,0,0), no single-step exit | φ, f₂, K₁ — 3 particles |
| **V Anomaly** | ~0.002 | U(1)_A cross-force mixing | η'(958) — 1 particle |

**The hierarchy:** Σ(I) ≈ 1 > Σ(II) ≈ 0.4 > Σ(III) ≈ 0.1 > Σ(IV) = 0 > Σ(V) ≈ 0.002.

**Key structural result:** Σ(IV) = 0 is a theorem (BDG arithmetic on
profile (2,2,0,0) gives no single-step exit). Other Σ values are empirical
filter strengths.

## 2. What today's insight adds: the weak-decay extension

The April 10–11 work restricted itself to strong decays by construction
(see `sigma_table.py` line 245: `if p['decay_force'] not in ['strong']: continue`).
The following particles fall outside that scope:

| Particle | τ_obs | Decay | Why excluded |
|----------|-------|-------|--------------|
| π⁰ | 8.5×10⁻¹⁷ s | γγ | EM decay |
| π± | 2.6×10⁻⁸ s | μν | weak decay |
| K± | 1.2×10⁻⁸ s | various | weak |
| K_S | 0.9×10⁻¹⁰ s | ππ | weak |
| K_L | 5.1×10⁻⁸ s | πππ/πeν | weak |
| muon | 2.2×10⁻⁶ s | eνν | weak |
| neutron | 880 s | peν | weak |
| tau | 2.9×10⁻¹³ s | various | weak |

These are the particles with the largest gaps in the existing lifetime
predictions (bdg_multicoupling.py shows 10–25 orders of magnitude error
for cross-force decays). They are also the particles whose instability
motivated today's insight about internal symmetries.

## 3. The extension in RA-native terms

The strong-decay σ-filter framework has these primitives:
- Motif M with BDG profile N = (N₁, N₂, N₃, N₄)
- σ-labels: isospin I, G-parity G, strangeness S, baryon number B
- Daughter admissibility: which n-body channels conserve σ-labels
- Exit probability p_exit from BDG arithmetic + σ-filtering

The weak-decay extension introduces **one additional primitive**:
- **Weak-vertex access requirement**: whether the motif's propagation
  requires a vertex with Q_{N₃/N₄} ≠ 0 at some step

The reason this is one primitive, not a new framework, is that it sits
inside the existing BDG structure: N₃ and N₄ are already counted, c₃ = −16
(most negative coefficient, most heavily penalized) and c₄ = +8 are already
in the action, and the RASM §6 machinery already assigns weak isospin =
N₃/N₄ handedness charge.

### 3.1 The weak-vertex access probability P_WVA

For a motif with profile N and decay channel requiring change in
N₃/N₄ content:

$$P_{\text{WVA}}(\mathcal{M}) = P(\text{next extension creates N}_3 \text{ or N}_4 \text{ content necessary for decay channel})$$

From the BDG filter Monte Carlo (`selective regime` table in RASM §Selective):
- At μ = 4.7 (hadronic regime): ΔN₃ = −3.17 (strongly suppressed)
- At μ = 1.0 (quasi-stable): ΔN₃ = −0.14 (mildly suppressed)

The probability of N₃ activation survives the filter at rate
$e^{c_3} = e^{-16} \approx 1.1 \times 10^{-7}$ for bare suppression, 
modified by the local density.

### 3.2 Relation to the existing 5-type framework

| Type | Decay mechanism | Σ_eff or analog |
|------|----------------|-----------------|
| I Direct | Strong N₁/N₂-only exit | Σ ≈ 1 |
| II Strangeness | Strong, with σ-label cost | Σ ≈ 0.4 |
| III G-parity | Strong, forced multi-step | Σ ≈ 0.1 |
| IV Topology | Strong multi-step only | Σ = 0 + branching volume |
| V Anomaly | η': near-weak character | Σ ≈ 0.002 |
| **VI Weak** (new) | Requires N₃/N₄ vertex | $\Sigma_{\rm weak} \approx ?$ for π, K, n, μ |

**The claim:** Type VI is to weak decays what Types I–V are to strong decays.
Its Σ values should follow the same per-mechanism structural constants:
no filter (Σ=1), strangeness cost (Σ×0.4), G-parity cost (Σ×0.1),
weak-vertex access cost (Σ×10⁻⁷ or similar), and so on.

### 3.3 The η' as bridge

η' is Type V (anomaly) at Σ = 0.002 ≈ 1/500. This is a smaller suppression
than the full weak-vertex access factor (10⁻⁷ for bare N₃ activation)
because η' decays via the U(1)_A anomaly, which provides partial access
to the weak-like channel without requiring a full W-like vertex.

In other words: η' demonstrates that **intermediate values of Σ between
Type IV (0, pure topology) and Type VI (~10⁻⁷, full weak vertex) exist
and can be populated**. The Σ-filter space is a continuum, not a discrete
hierarchy.

## 4. Specific predictions (for falsification)

Three numerical targets from the weak-decay extension:

### 4.1 Charged pion lifetime

π±: profile (2,0,0,0), τ_obs = 2.6×10⁻⁸ s, decay π± → μν.

The decay vertex is a qq̄ annihilation via W into lepton pair. This
requires the pion's propagation to access an N₃/N₄ vertex at rate
P_WVA(π±). The lifetime is then:

$$\tau_{\pi^\pm} = L_q \cdot (\hbar/m_\pi c^2) / P_{\rm WVA}(\pi^\pm)$$

Target: P_WVA(π±) ≈ 10⁻¹⁷ (extracting from τ_obs and τ_Compton):
$$P_{\rm WVA}(\pi^\pm) = \frac{L_q \cdot \hbar / m_\pi c^2}{\tau_{\rm obs}} = \frac{4 \cdot 4.7 \times 10^{-24}}{2.6 \times 10^{-8}} \approx 7 \times 10^{-16}$$

Derivation from BDG structure: open target. But the magnitude is close to
(α_weak/α_strong)² ~ (1/30 × 0.118)⁻² ~ 6×10⁻⁵ × (strong cycle factor)
or to something involving e^{c_3/c_4} = e^{-2} ≈ 0.135 raised to a
power related to the weak-vertex depth.

### 4.2 K_L vs K_S lifetime ratio

τ_{K_L}/τ_{K_S} = 5.1×10⁻⁸ / 0.9×10⁻¹⁰ ≈ 570.

In the Standard Model this is CP violation in the kaon system. In RA-native
language, K_S and K_L differ by their CP structure, which maps to different
N₃/N₄ handedness content. The ratio 570 should be derivable from the
difference in P_WVA between the CP-even and CP-odd kaon combinations.

### 4.3 Cross-force factor from BDG integers

The apparent discrepancy between τ_neutron and τ_Δ (both baryons, similar
mass) spans 27 orders of magnitude. This ratio should factor as:

$$\frac{\tau_n}{\tau_\Delta} = \frac{P_{\rm WVA}(\Delta)}{P_{\rm WVA}(n)} \cdot \text{(mass and kinematic factors)}$$

The target is to show this factor is structurally derivable from the
BDG coefficients (specifically the ratio c₃/c₄ = −2 and the factorial
suppression |c_k|/k!).

## 5. Research roadmap

**Ready for Paper II §6.5:** The five-type classification (Types I–V) 
stands as a validated RA-native framework for strong decays. Draft text
in `Paper_II_Section_6.5_Draft.tex`.

**Extension program (this synthesis):**

1. **Short-term (1 session):** Extend `sigma_table.py` to include weakly-decaying
   particles with their σ-labels (already partially done in lines 112-113).
   Add a Type VI classifier with P_WVA as the filter strength.

2. **Medium-term (2–3 sessions):** Compute P_WVA from the BDG filter MC for the
   π±, K±, K_L, K_S patterns. Check whether the values match observation
   within factor 10 (the precedent: Types I–V match within factor ~3).

3. **Longer-term:** Branching-volume program for Type IV multi-step paths
   (φ→KK̄, f₂→ππ) and for Type VI weak-path counting.

## 6. What this replaces in the earlier synthesis

The `RA_Pion_Kaon_Synthesis.md` v1 document was correct in structure but
treated the weak-vertex-access mechanism as a novel proposal. It is not:
it is the natural extension of the Apr 10–11 σ-filter framework from 
strong to weak decays. The replacement:

- v1: "pion instability has a specific RA-native mechanism (weak-vertex BDG debt)"
- v2 (this document): "pion instability is a Type VI σ-filter case, extending
  the established five-type classification to weak decays"

- v1: "mass and lifetime are outputs of the same structural calculation"  
- v2: "Type V η' already demonstrates this: its mass (958 MeV, 1.8% from
  baryon cascade) and its lifetime (Σ=0.002, 500× normal) are both outputs
  of its Type V structural position"

- v1: "Goldstone mechanism replaced by weak-vertex leakage"  
- v2: unchanged, this remains the correct move

## 7. Epistemic status summary

| Claim | Tier | Source |
|-------|------|--------|
| Five-type strong-decay σ-filter classification | CV | sigma_analysis.py, 19 particles |
| Σ(I–V) values in Eq.~(sigma_hierarchy) | CV | reproduce exactly |
| Type IV profile (2,2,0,0) → Σ = 0 | DR | BDG arithmetic theorem |
| η' at baryon cascade (958 MeV ≈ 941 MeV, 1.8%) | PI + synthesis | Type V structural position |
| Extension to weak decays (Type VI) | CN | This synthesis |
| P_WVA(π±) ≈ 7×10⁻¹⁶ target | CN | Extracted from τ_obs |
| K_L/K_S ratio = 570 from BDG | OP | Research target |
| Cross-force factor ~10⁻²⁷ from c_k integers | OP | Research target |
