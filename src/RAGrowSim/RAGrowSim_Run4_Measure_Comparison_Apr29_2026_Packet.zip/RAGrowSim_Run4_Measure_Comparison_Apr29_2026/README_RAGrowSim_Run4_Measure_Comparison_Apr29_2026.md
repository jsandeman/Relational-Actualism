# RAGrowSim Run-4 Measure Comparison Packet

This packet interprets the uploaded `measure_comparison_*` outputs.

Main report:

- `reports/RAGrowSim_Measure_Comparison_Interpretation_Apr29_2026.md`

Key derived CSVs:

- `reports/measure_comparison_overall_summary_Apr29_2026.csv`
- `reports/measure_vs_conditional_poisson_exact_mu_v4_residuals_Apr29_2026.csv`
- `reports/accepted_conditional_poisson_exact_mu_v4_baseline_Apr29_2026.csv`
- `reports/candidate_measure_step_degeneracy_Apr29_2026.csv`
- `reports/measure_comparison_top_profiles_Apr29_2026.csv`
- `reports/candidate_profile_multiplicity_top_Apr29_2026.csv`

RAKB hold file:

- `registry_hold/RAKB_growth_measure_methodology_issues_hold_v1_Apr29_2026.yaml`

Recommendation: apply the issues after review; do not change claims yet.

Optional next-run script:

- `scripts/run_action_weighted_measure_comparison.jl`

Run from RAGrowSim root:

```bash
julia --project=. scripts/run_action_weighted_measure_comparison.jl 25 50 outputs/action_weighted_measure_comparison 4
```
