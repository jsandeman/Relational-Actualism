# RAGrowSim Measure-Comparison Interpretation — Apr 29, 2026

## Executive verdict

This run is the first direct comparison between three finite-growth candidate measures:

1. `parent_subset_uniform`: every admitted explicit parent subset counts separately.
2. `closure_uniform`: duplicate parent subsets inducing the same causal closure/downset are quotiented.
3. `profile_uniform`: candidates are quotiented further to BDG profiles `(N1,N2,N3,N4)`.

The key result is:

> Quotienting by closure/profile does **not** simply recover accepted-conditional Poisson.  
> It changes the discrepancy. `profile_uniform` is closest for aggregate BDG action `S`, but no tested measure matches the accepted-conditional Poisson profile channel-by-channel.

This means the next theoretical object is the **RA actualization measure**: what is the physical sample space of structured potentia?

## Overall measure comparison

Averages over 4 seeds × 50 runs × 25 growth steps = 5000 realized vertices per measure:

| measure | <N1> | <N2> | <N3> | <N4> | <S> | <parent size> | <mu_v4> |
|---|---:|---:|---:|---:|---:|---:|---:|
| `closure_uniform` | 2.4514 | 1.9294 | 0.5346 | 0.8964 | 14.5308 | 2.4514 | 1.8487 |
| `parent_subset_uniform` | 1.7276 | 1.9030 | 0.6950 | 0.9262 | 12.6890 | 3.3812 | 1.8195 |
| `profile_uniform` | 2.3018 | 1.9908 | 0.5294 | 0.9466 | 15.7178 | 2.3018 | 1.8192 |


The measures produce materially different motif ecologies.

* `parent_subset_uniform` has lower `N1`, higher `N3`, and lower aggregate action.
* `closure_uniform` raises `N1`, lowers `N3`, and improves `N4` agreement with accepted-conditional Poisson.
* `profile_uniform` gives the best aggregate action agreement but overweights low-degeneracy/vacuum-like profiles.

## Exact μ_v4 accepted-conditional Poisson residuals

For each realized vertex, I recomputed the accepted-conditional independent-Poisson baseline at that vertex's exact `mu_v4` value, rather than relying only on coarse bins.

| measure | sim/cond N1 | sim/cond N2 | sim/cond N3 | sim/cond N4 | sim/cond S |
|---|---:|---:|---:|---:|---:|
| `closure_uniform` | 1.4168 | 0.7905 | 0.7514 | 1.0050 | 0.8553 |
| `parent_subset_uniform` | 1.0189 | 0.8370 | 1.2489 | 1.3219 | 0.7705 |
| `profile_uniform` | 1.3512 | 0.8245 | 0.7399 | 1.0546 | 0.9378 |


Interpretation:

* `parent_subset_uniform` is closest in `N1`, `N2`, and `N3`, but overshoots `N4` and underproduces aggregate action:
  `S` ratio ≈ 0.7705.
* `closure_uniform` is nearly perfect in `N4`, but has too much `N1`, too little `N2/N3`, and lower action:
  `S` ratio ≈ 0.8553.
* `profile_uniform` is closest in aggregate action:
  `S` ratio ≈ 0.9378,
  but still has too much `N1` and too little `N2/N3`.

So the result is not “Poisson vindicated” and not “Poisson falsified.” It is:

> finite growth depends strongly on the candidate measure; accepted-conditional Poisson remains a comparison ensemble, not yet the derived finite-growth law.

## Candidate-measure degeneracy

The parent-subset diagnostic remains decisive. At step 25, averaged over seeds/runs:

| quantity | value |
|---|---:|
| total parent subsets | 22594.0 |
| admitted parent subsets | 9577.9 |
| unique closures | 850.4 |
| admitted unique closures | 419.3 |
| unique profiles | 151.8 |
| admitted unique profiles | 76.6 |
| total subset / closure multiplicity | 32.18× |
| admitted subset / closure multiplicity | 27.61× |
| mean max admitted closure multiplicity | 676.4 |


This means `parent_subset_uniform` is not a neutral discretization. It gives large multiplicity weights to closures that have many redundant parent-set representations.

Some profiles are enormously multiplicity-amplified under parent-subset counting. The top admitted profile multiplicities include:

| profile | admitted candidate count | admitted unique closures | candidate/closure |
|---|---:|---:|---:|
| `1|3|2|2` | 4053 | 3 | 1351.00× |
| `1|4|1|1` | 13110 | 12 | 1092.50× |
| `1|4|2|0` | 7289 | 9 | 809.89× |
| `1|2|2|2` | 69037 | 115 | 600.32× |
| `1|4|2|1` | 2880 | 5 | 576.00× |
| `1|3|2|1` | 121829 | 254 | 479.64× |
| `1|3|1|1` | 51414 | 111 | 463.19× |
| `2|2|3|4` | 554 | 2 | 277.00× |
| `2|5|2|2` | 254 | 1 | 254.00× |
| `2|5|3|1` | 1758 | 7 | 251.14× |


## Top selected profiles by measure

The most frequent profiles also show that none of the three measures is obviously canonical.

| measure | top profiles |
|---|---|
| `parent_subset_uniform` | `1|1|1|1` (8.20%), `1|2|1|0` (6.72%), `2|2|1|1` (6.02%), `1|2|1|1` (4.78%), `2|1|1|2` (3.80%) |
| `closure_uniform` | `0|0|0|0` (6.52%), `1|1|0|0` (5.64%), `2|1|0|0` (3.86%), `1|2|1|0` (2.94%), `3|1|0|1` (2.92%) |
| `profile_uniform` | `0|0|0|0` (8.48%), `1|1|0|0` (5.58%), `2|1|0|0` (3.94%), `1|2|1|0` (3.08%), `2|2|1|0` (2.34%) |


The vacuum/isolate profile `0|0|0|0` has frequency:

| measure | frequency |
|---|---:|
| `closure_uniform` | 6.52% |
| `parent_subset_uniform` | 2.60% |
| `profile_uniform` | 8.48% |


This is a warning against treating `profile_uniform` as automatically physical merely because it best matches aggregate action. It also overweights low-degeneracy profiles such as isolated births.

## Theoretical interpretation

The current data suggests a three-way fork:

### 1. Parent-subset measure

This is physical only if explicit direct parent links are independent ontological structure, not merely redundant encodings of the same causal closure.

Problem: it strongly depends on combinatorial multiplicity and produces a lower-action ensemble.

### 2. Closure/frontier measure

This is physical if the actualized object is a causal closure/downset with frontier links as the immediate boundary. This is attractive for RA if charge/ledger signs are topological incidence data on a local boundary.

Problem: it does not match accepted-conditional Poisson channel-by-channel, and it overproduces `N1`.

### 3. Profile/action measure

This is physical if the BDG kernel acts primarily on profile classes rather than individual embeddings.

Problem: pure profile-uniform has too much vacuum/isolate sampling and too much `N1`. It is closest in aggregate `S`, but not in the full profile vector.

## Implication for the ledger rule

This run was Neutral, so it does not test charge. But it directly constrains the future charge simulator.

If the ledger rule is topological, it should probably attach to:

```text
oriented closure/frontier/incidence structure
```

not to arbitrary redundant parent subsets.

That supports the hypothesis:

```text
N2 winding / branching structure -> boundary projection -> signed N1 ledger
```

where the signed electric ledger is a readout of oriented incidence on the local boundary. The sample space should then be closures/frontiers plus orientation/incidence data, not all redundant parent subsets.

## RAKB recommendation

Now it is appropriate to update RAKB with **methodological issues**, but still not with claim demotions.

Recommended additions:

* `RA-OPEN-GROWTH-MEASURE-001`: define the RA-native candidate measure for structured potentia.
* `RA-OPEN-POISSON-DYNAMICS-001`: determine when finite RA growth approximates accepted-conditional Poisson-CSG.
* `RA-OPEN-MU-ESTIMATOR-001`: define an RA-native local density estimator.
* Optionally, `RA-OPEN-GROWTH-KERNEL-WEIGHT-001`: determine whether actualization is uniform among admitted candidates or weighted by a BDG kernel/action.

Do **not** demote Poisson-based paper results yet. This run shows that the growth measure is underspecified; it does not yet prove that the closed-form Poisson layer is invalid.

## Next run

The next run should compare not only uniform measures, but also kernel/action-weighted measures over closures and profiles:

```text
closure_uniform
closure_weight_S
closure_weight_exp_beta_S
profile_uniform
profile_weight_S
profile_weight_exp_beta_S
```

Use mild beta values first, e.g.:

```text
β ∈ {0.05, 0.10, 0.25}
```

The question is:

> Is accepted-conditional Poisson approximated by an RA-native action-weighted closure/profile measure?

If yes, then the paper Poisson layer may survive as an effective ensemble for a particular kernel measure. If no, the Poisson layer should be reclassified as comparative/asymptotic rather than generative.

## Included optional script

This packet includes `scripts/run_action_weighted_measure_comparison.jl` to test closure/profile measures weighted by `S` or by `exp(βS)` for β = 0.05, 0.10, 0.25.
